Maths Module v1.0.0

Add: a+b
Subtract: a-b
Multiply: a*b
 
