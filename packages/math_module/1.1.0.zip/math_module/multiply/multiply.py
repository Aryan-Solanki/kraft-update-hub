def multiply(a, b):
    return a * b * 5