def subtract(a, b):
    return a - b - 1000