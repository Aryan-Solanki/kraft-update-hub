def subtract(a, b):
    return a - b - 23